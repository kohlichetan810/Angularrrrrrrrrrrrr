package com.cg.ibs.loanmgmt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.ibsexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service("viewHistoryService")
public class ViewHistoryServiceImpl implements ViewHistoryService {
	@Autowired
	LoanMasterDao loanMasterDao;
	@Autowired
	CustomerDao customerDao;
	@Autowired
	ApplyLoanService applyLoanService;

	@Override
	public List<LoanMasterModel> getAllLoans(String userId) throws IBSException {
		List<LoanMasterEntity> allLoans = loanMasterDao.findByCustomer(customerDao.findByUserId(userId));
		List<LoanMasterModel> allLoansModel = new ArrayList<LoanMasterModel>();
		if(allLoans.isEmpty()) {
			throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
		}else {
		for (LoanMasterEntity loanMasterEntity : allLoans) {
			LoanMasterModel loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
			allLoansModel.add(loanMasterModel);
		}
		}
		return allLoansModel;
	}

}
