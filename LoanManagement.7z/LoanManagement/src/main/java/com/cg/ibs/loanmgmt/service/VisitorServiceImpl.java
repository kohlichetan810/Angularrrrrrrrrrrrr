package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.LoanTypeDao;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.Customer;
import com.cg.ibs.loanmgmt.entities.LoanTypeEntity;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.CustomerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;
import com.cg.ibs.loanmgmt.model.LoanTypeModel;

@Service("visitorService")
public class VisitorServiceImpl implements VisitorService {

	@Autowired
	LoanTypeDao loanTypeDao;
	@Autowired
	CustomerDao customerDao;
	@Autowired
	BankerDao bankerDao;

	@Override
	public LoanTypeModel getTypeOfLoan(Integer typeId) {
		LoanTypeEntity loanTypeEntity = loanTypeDao.findById(typeId).get();
		LoanTypeModel loanTypeModel = valueOf(loanTypeEntity);
		return loanTypeModel;
	}

	private LoanTypeModel valueOf(LoanTypeEntity loanTypeEntity) {
		LoanTypeModel loanTypeModel = new LoanTypeModel();
		loanTypeModel.setInterestRate(loanTypeEntity.getInterestRate());
		loanTypeModel.setLoanType(loanTypeEntity.getLoanType());
		loanTypeModel.setMaximumLimit(loanTypeEntity.getMaximumLimit());
		loanTypeModel.setMinimumLimit(loanTypeEntity.getMinimumLimit());
		loanTypeModel.setTypeId(loanTypeEntity.getTypeId());
		return loanTypeModel;
	}

	public CustomerModel valueOf(Customer customer) {
		CustomerModel customerModel = new CustomerModel();
		customerModel.setAadharNumber(customer.getAadharNumber());
		customerModel.setAlternateMobileNumber(customer.getAlternateMobileNumber());
		customerModel.setApplicantId(customer.getApplicantId());
		customerModel.setDateofBirth(customer.getDateofBirth());
		customerModel.setEmailId(customer.getEmailId());
		customerModel.setFatherName(customer.getFatherName());
		customerModel.setFirstName(customer.getFirstName());
		customerModel.setGender(customer.getGender());
		customerModel.setLastname(customer.getLastname());
		customerModel.setMobileNumber(customer.getMobileNumber());
		customerModel.setMotherName(customer.getMotherName());
		customerModel.setPassword(customer.getPassword());
		customerModel.setUci(customer.getUci());
		customerModel.setUserId(customer.getUserId());
		return customerModel;
	}

	private BankerModel valueOf(Banker banker) {
		BankerModel bankerModel = new BankerModel();
		bankerModel.setBankerId(banker.getBankerId());
		bankerModel.setPassword(banker.getPassword());
		bankerModel.setUserId(banker.getUserId());
		return bankerModel;
	}

	@Override
	public CustomerModel verifyCustomerLogin(String userId, String password) {
		Customer customer = customerDao.findByUserId(userId);
		CustomerModel customerModel;
		if (customer.getPassword().equals(password)) {
			customerModel = valueOf(customer);
		} else {
			customerModel = null;
		}
		return customerModel;
	}

	@Override
	public BankerModel verifyBankerLogin(String userId, String password) {
		Banker banker = bankerDao.findByUserId(userId);
		BankerModel bankerModel;
		if (banker.getPassword().equals(password)) {
			bankerModel = valueOf(banker);
		} else {
			bankerModel = null;
		}
		return bankerModel;
	}

	@Override
	public BigDecimal calculatePaidInterest(LoanMasterModel loanMasterModel) {
				BigDecimal balance = loanMasterModel.getBalance();
				Float rate = loanMasterModel.getLoanInterest() / 100;
				BigDecimal paidInterest = (balance.multiply(BigDecimal.valueOf(Math.pow(1 + rate, 1.0 / 12.0)))
						.subtract(balance));
				return paidInterest;
	}

	@Override
	public BigDecimal calculatePaidPrinciple(LoanMasterModel loanMasterModel) {
		BigDecimal paidPrinciple = loanMasterModel.getEmiAmount().subtract(calculatePaidInterest(loanMasterModel));
		return paidPrinciple;
	}
}
