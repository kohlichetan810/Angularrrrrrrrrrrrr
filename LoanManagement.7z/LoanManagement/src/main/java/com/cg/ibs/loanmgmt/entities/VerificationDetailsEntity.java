package com.cg.ibs.loanmgmt.entities;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "loan_query_details")
@SequenceGenerator(name = "loan_query_seq", initialValue = 1, allocationSize = 1)
public class VerificationDetailsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "loan_query_seq")
	@Column(name = "loan_queryId", nullable = false)
	private Long loanQueryId;
	@Column(name = "application_num", nullable = false)
	private BigInteger applicationNumber;
	@Enumerated(EnumType.STRING)
	@Column(name = "QueryStatus", nullable = false)
	private LoanStatus queryStatus;
	@Column(name = "remarks", nullable = true)
	private String remarks;

	public Long getLoanQueryId() {
		return loanQueryId;
	}

	public void setLoanQueryId(Long loanQueryId) {
		this.loanQueryId = loanQueryId;
	}

	public BigInteger getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(BigInteger applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public LoanStatus getQueryStatus() {
		return queryStatus;
	}

	public void setQueryStatus(LoanStatus queryStatus) {
		this.queryStatus = queryStatus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
