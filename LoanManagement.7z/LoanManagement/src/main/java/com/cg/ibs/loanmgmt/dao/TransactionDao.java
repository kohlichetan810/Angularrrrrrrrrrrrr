package com.cg.ibs.loanmgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.entities.Transaction;

@Repository("transaction")
public interface TransactionDao extends JpaRepository<Transaction, Integer> {

}
