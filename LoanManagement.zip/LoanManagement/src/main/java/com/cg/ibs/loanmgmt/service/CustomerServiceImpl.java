package com.cg.ibs.loanmgmt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.entities.Customer;
import com.cg.ibs.loanmgmt.model.CustomerModel;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao customerDao;
	@Autowired
	VisitorService visitorService;

	@Override
	public CustomerModel getCustomer(String userId) {
		Customer customerEntity = customerDao.findByUserId(userId);
		CustomerModel customer = visitorService.valueOf(customerEntity); 
		return customer;
	}

}
