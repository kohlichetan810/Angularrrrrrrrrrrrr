package com.cg.ibs.loanmgmt.entities;

public enum TransactionType {
	CREDIT, DEBIT;
}
