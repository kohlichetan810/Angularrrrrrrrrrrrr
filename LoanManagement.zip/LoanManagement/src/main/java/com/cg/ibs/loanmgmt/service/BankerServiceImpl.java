package com.cg.ibs.loanmgmt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service("bankerService")
public class BankerServiceImpl implements BankerService {
	@Autowired
	BankerDao bankerDao;
	@Autowired
	LoanMasterDao loanMasterDao;
	@Autowired
	ApplyLoanService applyLoanService;

	@Override
	public BankerModel findBankerByUserId(String userId) {
		
		Banker bankerEntity = bankerDao.findByUserId(userId);
		System.out.println("hello");
		BankerModel banker = valueOf(bankerEntity);
		return banker;
		}

	@Override
	public BankerModel valueOf(Banker banker) {
		BankerModel bankerModel = new BankerModel();
		bankerModel.setBankerId(banker.getBankerId());
		bankerModel.setUserId(banker.getUserId());
		bankerModel.setPassword(banker.getPassword());
		return bankerModel;
	}

	@Override
	public Banker valueOf(BankerModel banker) {
		Banker bankerEntity =new Banker();
		bankerEntity.setBankerId(banker.getBankerId());
		bankerEntity.setUserId(banker.getUserId());
		bankerEntity.setPassword(banker.getPassword());
		return bankerEntity;
	}

	@Override
	public List<LoanMasterModel> getAllAppliedLoans() {
		List<LoanMasterEntity> applLoans = loanMasterDao.findAllVerificationLoans();
		List<LoanMasterModel> appliedLoans = new ArrayList<>();
		for (LoanMasterEntity loanMasterEntity : applLoans) {
			LoanMasterModel loanMasterModel = new LoanMasterModel();
			loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
			appliedLoans.add(loanMasterModel);
		}
		return appliedLoans;
	}

	@Override
	public List<LoanMasterModel> getAllAppliedPreClosureLoans() {
		List<LoanMasterEntity> preLoans = loanMasterDao.findAllPreVerificationLoans();
		List<LoanMasterModel> appliedPreClosureLoans = new ArrayList<>();
		for (LoanMasterEntity loanMasterEntity : preLoans) {
			LoanMasterModel loanMasterModel = new LoanMasterModel();
			loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
			appliedPreClosureLoans.add(loanMasterModel);
		}
		return appliedPreClosureLoans;
	}
	
	
	
}
