package com.cg.ibs.loanmgmt.controller;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.ibsexception.ExceptionMessages;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;
import com.cg.ibs.loanmgmt.service.ApplyLoanService;
import com.cg.ibs.loanmgmt.service.ApplyPreClosureService;
import com.cg.ibs.loanmgmt.service.PayEmiService;
import com.cg.ibs.loanmgmt.service.ViewHistoryService;

@RestController
@RequestMapping("/IBS/Customer")
@CrossOrigin
public class CustomerController {
	@Autowired
	ApplyLoanService applyLoanService;
	@Autowired
	PayEmiService payEmiService;
	@Autowired
	ApplyPreClosureService applyPreClosureService;
	@Autowired
	ViewHistoryService viewHistory;

	@GetMapping("/{userId}")
	public ResponseEntity<List<AccountModel>> getSavingsAccounts(@PathVariable("userId") String userId)
			throws IBSException {
		ResponseEntity<List<AccountModel>> result = null;
		List<AccountModel> userSavingsAccounts = new ArrayList<AccountModel>();
		if (userId.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			userSavingsAccounts = applyLoanService.findSavingsAccountsByCustomer(userId);
			result = new ResponseEntity<List<AccountModel>>(userSavingsAccounts, HttpStatus.OK);
		}
		return result;
	}

	@PostMapping("/applyLoan")
	public ResponseEntity<LoanMasterModel> applyLoan(@RequestBody LoanMasterModel loanMasterModel) throws IBSException {
		ResponseEntity<LoanMasterModel> result = null;
		if (loanMasterModel.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			loanMasterModel = applyLoanService.applyLoan(loanMasterModel);
			result = new ResponseEntity<>(loanMasterModel, HttpStatus.OK);
		}
		return result;
	}

	@GetMapping("/activeLoans/{userId}")
	public ResponseEntity<List<LoanMasterModel>> activeEmiLoans(@PathParam("userId") String userId)
			throws IBSException {
		ResponseEntity<List<LoanMasterModel>> result = null;
		List<LoanMasterModel> emiLoans = new ArrayList<LoanMasterModel>();
		if (userId.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			emiLoans = payEmiService.getApprovedLoanListByUserId(userId);
			result = new ResponseEntity<>(emiLoans, HttpStatus.OK);
		}
		return result;
	}

	@PostMapping("/emiSavingsAcc")
	public ResponseEntity<List<AccountModel>> getEmiSavingsAccounts(@RequestBody LoanMasterModel loanMasterModel)
			throws IBSException {
		ResponseEntity<List<AccountModel>> result = null;
		List<AccountModel> userSavingsAccounts = new ArrayList<AccountModel>();
		if (loanMasterModel.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			userSavingsAccounts = payEmiService.findSavingsAccountsByCustomer(loanMasterModel.getCustomerUserId(),
					loanMasterModel.getLoanAccountNumber());
			result = new ResponseEntity<List<AccountModel>>(userSavingsAccounts, HttpStatus.OK);
		}
		return result;
	}

	@PostMapping("/payEmi")
	public ResponseEntity<LoanMasterModel> payEmi(@RequestBody LoanMasterModel emiLoan) throws IBSException {
		ResponseEntity<LoanMasterModel> result = null;
		if (emiLoan.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			emiLoan = payEmiService.updateLoanPostEmi(emiLoan.getLoanAccountNumber(), emiLoan.getSavingsAccount());
			result = new ResponseEntity<>(emiLoan, HttpStatus.OK);

		}
		return result;
	}

	@GetMapping("/applicableEmiLoans/{userId}")
	public ResponseEntity<List<LoanMasterModel>> applicableLoansForEmi(@PathVariable("userId") String userId)
			throws IBSException {
		ResponseEntity<List<LoanMasterModel>> result = null;
		List<LoanMasterModel> applicableLoans = new ArrayList<LoanMasterModel>();
		if (userId.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			applicableLoans = payEmiService.getApprovedLoanListByUserId(userId);
			result = new ResponseEntity<>(applicableLoans, HttpStatus.OK);

		}
		return result;
	}

	@GetMapping("/applicablePreClosure/{userId}")
	public ResponseEntity<List<LoanMasterModel>> applicableLoansForPreClosure(@PathVariable("userId") String userId)
			throws IBSException {
		ResponseEntity<List<LoanMasterModel>> result = null;
		List<LoanMasterModel> applicableLoans = new ArrayList<LoanMasterModel>();
		if (userId.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else
			applicableLoans = applyPreClosureService.getPreClosureLoansByUserId(userId);
		result = new ResponseEntity<>(applicableLoans, HttpStatus.OK);

		return result;
	}

	@PostMapping("/preClosureSavingsAcc")
	public ResponseEntity<List<AccountModel>> getPreClosureSavingsAccounts(
			@RequestBody LoanMasterModel loanMasterModel) throws IBSException {
		ResponseEntity<List<AccountModel>> result = null;
		List<AccountModel> userSavingsAccounts = null;

		if (loanMasterModel.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else
			userSavingsAccounts = applyPreClosureService.findSavingsAccountsByCustomer(
					loanMasterModel.getLoanAccountNumber(), loanMasterModel.getCustomerUserId());
			result = new ResponseEntity<>(userSavingsAccounts, HttpStatus.OK);
		
		return result;
	}

	@PostMapping("/applyPreClosure")
	public ResponseEntity<LoanMasterModel> applyPreClosure(@RequestBody LoanMasterModel preClosureLoan) throws IBSException {
		ResponseEntity<LoanMasterModel> result = null;
		if (preClosureLoan.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			preClosureLoan = applyPreClosureService.applyPreClosure(preClosureLoan.getLoanAccountNumber(),
					preClosureLoan.getSavingsAccount());
			result = new ResponseEntity<>(preClosureLoan, HttpStatus.OK);
		}
		return result;
	}

	@GetMapping("/viewHistory/{userId}")
	public ResponseEntity<List<LoanMasterModel>> viewHistory(@PathVariable("userId") String userId) throws IBSException {
		ResponseEntity<List<LoanMasterModel>> result = null;
		List<LoanMasterModel> getAllLoans = new ArrayList<LoanMasterModel>();
		if (userId.equals(null)) {
			throw new IBSException(ExceptionMessages.MESSAGEFORWRONGINPUT);
		} else {
			getAllLoans = viewHistory.getAllLoans(userId);
				result = new ResponseEntity<>(getAllLoans, HttpStatus.OK);
			}
		return result;
	}

	@ExceptionHandler(IBSException.class)
	public ResponseEntity<String> handleAdbException(IBSException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
