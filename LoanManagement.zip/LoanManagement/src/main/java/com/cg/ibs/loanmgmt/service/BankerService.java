package com.cg.ibs.loanmgmt.service;

import java.util.List;

import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

public interface BankerService {
	BankerModel findBankerByUserId(String userId);
	BankerModel valueOf(Banker banker);
	Banker valueOf(BankerModel banker);
	
	List<LoanMasterModel> getAllAppliedLoans();
	List<LoanMasterModel> getAllAppliedPreClosureLoans();
}
