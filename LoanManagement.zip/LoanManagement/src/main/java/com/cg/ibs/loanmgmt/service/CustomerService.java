package com.cg.ibs.loanmgmt.service;

import com.cg.ibs.loanmgmt.model.CustomerModel;

public interface CustomerService {
	CustomerModel getCustomer(String userId);
}
