package com.cg.ibs.loanmgmt.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.entities.PaymentMode;
import com.cg.ibs.loanmgmt.ibsexception.IBSException;
import com.cg.ibs.loanmgmt.model.AccountModel;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;
import com.cg.ibs.loanmgmt.service.ApplyLoanService;
import com.cg.ibs.loanmgmt.service.ApplyPreClosureService;
import com.cg.ibs.loanmgmt.service.BankerService;
import com.cg.ibs.loanmgmt.service.PayEmiService;
import com.cg.ibs.loanmgmt.service.VerifyLoanService;
import com.cg.ibs.loanmgmt.service.VerifyPreClosureService;

@Component
public class User {
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private VerifyLoanService verifyLoanService;
	@Autowired
	private BankerService bankerService;
	@Autowired
	private PayEmiService payEmiService;
	@Autowired
	private ApplyPreClosureService applyPreClosureService;
	@Autowired
	private VerifyPreClosureService verifyPreClosureService;

	Scanner read = new Scanner(System.in);

	public void applyLoan() {
		LoanMasterModel loanMasterModel = new LoanMasterModel();
		List<AccountModel> savingAccounts = new ArrayList<AccountModel>();
		System.out.println("Enter userId:");
		loanMasterModel.setCustomerUserId(read.next());
		System.out.println("Enter type of Loan");
		loanMasterModel.setLoanTypeId(read.nextInt());
		System.out.println("Enter loanAmount:");
		loanMasterModel.setLoanAmount(read.nextBigDecimal());
		System.out.println("Enter loanTenure:");
		loanMasterModel.setLoanTenure(read.nextInt());
		applyLoanService.calculateEmi(loanMasterModel);
		System.out.println("EMI Amount: ");
		System.out.println(loanMasterModel.getEmiAmount());
		for (AccountModel accountModel : savingAccounts) {
			System.out.println(accountModel.getAccNo());
		}
		loanMasterModel.setSavingsAccount(new BigInteger("987654321032"));
		loanMasterModel = applyLoanService.applyLoan(loanMasterModel);
		System.out.println(loanMasterModel.getApplicationNumber());

	}

	public void verifyLoan() {
		BankerModel banker = new BankerModel();
		LoanMasterModel loanMasterModel = new LoanMasterModel();
		System.out.println("Enter user Id");
		banker.setUserId(read.next());
		banker = bankerService.findBankerByUserId(banker.getUserId());
		System.out.println(banker.getPassword());
		List<LoanMasterModel> pendingLoans = verifyLoanService.findLoansToBeVerified(banker);
		for (LoanMasterModel loanMasterModel1 : pendingLoans) {
			System.out.println(loanMasterModel1.getApplicationNumber());
			System.out.println(loanMasterModel1.getLoanAmount());
			System.out.println(loanMasterModel1.getLoanType());
		}

		System.out.println("Enter Loan Number to be verified");
		banker.setVerifyApplicationNumber(read.nextBigInteger());
		loanMasterModel = verifyLoanService.findLoanToBeVerified(banker);
		System.out.println(loanMasterModel.getApplicationNumber());
		System.out.println(loanMasterModel.getCustomerUserId());
		System.out.println(loanMasterModel.getLoanAmount());

		System.out.println("Enter Choice :");
		Integer choice = read.nextInt();
		System.out.println("Enter remarks");
		loanMasterModel.setRemarks(read.next());
		loanMasterModel = verifyLoanService.verifyLoan(loanMasterModel, choice);
		System.out.println(loanMasterModel.getStatus());
		System.out.println(loanMasterModel.getLoanAccountNumber());
	}

	public void payEmi() {
		LoanMasterModel loanMasterModel = new LoanMasterModel();
		List<LoanMasterModel> activeLoans = new ArrayList<LoanMasterModel>();
		List<AccountModel> savingAccounts = new ArrayList<AccountModel>();
		System.out.println("Enter userId:");
		String userId = read.next();
		loanMasterModel.setCustomerUserId(userId);
		try {
			activeLoans = payEmiService.getApprovedLoanListByUserId(loanMasterModel.getCustomerUserId());
		} catch (IBSException e) {
			e.printStackTrace();
		}
		for (LoanMasterModel loanMasterModel2 : activeLoans) {
			System.out.println(loanMasterModel2.getApplicationNumber());
			System.out.println(loanMasterModel2.getLoanAccountNumber());
		}
		System.out.println("Enter Loan for EMI payment");
		loanMasterModel.setLoanAccountNumber(read.nextBigInteger());
		try {
			loanMasterModel = payEmiService.getLoanByLoanNum(loanMasterModel.getLoanAccountNumber());
		} catch (IBSException e) {
			e.printStackTrace();
		}
		System.out.println(loanMasterModel.getApprovedDate());
		System.out.println("Enter to Pay(1) or Not(2) :");
		Integer choice = read.nextInt();
		LoanMasterModel l = new LoanMasterModel();
		switch (choice) {
		case 1:
			try {
				savingAccounts = payEmiService.findSavingsAccountsByCustomer(userId, loanMasterModel);
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
			for (AccountModel accountModel : savingAccounts) {
				System.out.println(accountModel.getAccNo());
				System.out.println(accountModel.getAccCreationDate());
			}
			System.out.println("Enter Account Number to pay it from");
			BigInteger accNo = read.nextBigInteger();

			try {
				l = payEmiService.updateLoanPostEmi(loanMasterModel.getLoanAccountNumber(), accNo);
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
			break;

		case 2:
			System.out.println("ThankYou");
			break;
		}

		System.out.println(l.getNumOfEmisPaid());

	}

	public void applyPreClosure() {
		LoanMasterModel loanMasterModel = new LoanMasterModel();
		List<LoanMasterModel> pendingPreClosureLoans = new ArrayList<LoanMasterModel>();
		List<AccountModel> savingAccounts = new ArrayList<AccountModel>();

		System.out.println("Enter userId:");
		loanMasterModel.setCustomerUserId(read.next());
		try {
			pendingPreClosureLoans = applyPreClosureService
					.getPreClosureLoansByUserId(loanMasterModel.getCustomerUserId());
		} catch (IBSException e) {
			e.printStackTrace();
		}
		for (LoanMasterModel loanMasterModel2 : pendingPreClosureLoans) {
			System.out.println(loanMasterModel2.getLoanAccountNumber());
		}

		System.out.println("Enter Loan Number for Details:");
		loanMasterModel.setLoanAccountNumber(read.nextBigInteger());
		// return loanDetails
		System.out.println("Enter Choice : ");
		Integer choice = read.nextInt();
		switch (choice) {
		case 1:
			savingAccounts = applyPreClosureService.findSavingsAccountsByCustomer(loanMasterModel);
			for (AccountModel accountModel : savingAccounts) {
				System.out.println(accountModel.getAccNo());
			}
			System.out.println("Enter account Number :");
			loanMasterModel.setSavingsAccount(read.nextBigInteger());
			loanMasterModel = applyPreClosureService.applyPreClosure(loanMasterModel);
			System.out.println(loanMasterModel.getStatus());
			break;

		case 2:
			System.out.println("Thankyou");
			break;
		}

	}

	public void verifyPreClosure() {
		BankerModel banker = new BankerModel();
		List<LoanMasterModel> pendingPreClosureLoans = new ArrayList<LoanMasterModel>();
		LoanMasterModel loanMasterModel = new LoanMasterModel();
		System.out.println("Enter user Id");
		banker.setUserId(read.next());
		banker = bankerService.findBankerByUserId(banker.getUserId());
		pendingPreClosureLoans = verifyPreClosureService.findPreClosureLoansToBeVerified(banker);
		for (LoanMasterModel loanMasterModel4 : pendingPreClosureLoans) {
			System.out.println(loanMasterModel4.getLoanAccountNumber());
		}

		System.out.println("Enter Loan Account Number:");
		banker.setPreClosureVerifyLoanNumber(read.nextBigInteger());
		verifyPreClosureService.findPreClosureLoanToBeVerified(banker.getPreClosureVerifyLoanNumber());
		System.out.println("Enter Choice");
		Integer choice = read.nextInt();
		loanMasterModel.setLoanAccountNumber(banker.getPreClosureVerifyLoanNumber());
		System.out.println("Enter Remarks for the choice");
		loanMasterModel.setRemarks(read.next());
		try {
			loanMasterModel = verifyPreClosureService.verifyPreClosure(loanMasterModel, choice);
		} catch (IBSException e) {
			e.printStackTrace();
		}
		System.out.println(loanMasterModel.getStatus());
	}
}
